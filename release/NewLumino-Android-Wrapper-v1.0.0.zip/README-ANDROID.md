# NewLumino Android Release Package

## Build Instructions:
1. Initialize Capacitor:
   npx @capacitor/cli init "NewLumino" "com.newlumino.studio" --web-dir dist
2. Add Android target:
   npx cap add android
3. Copy AndroidManifest.xml and capacitor.config.json into android/
4. Open and build in Android Studio or run:
   ./gradlew assembleRelease
